import React from "react";
import ReactModal from "react-modal";
import { Icon } from "semantic-ui-react";
import '../styles/style.css';

import { getStatusLabel, getFormattedDate } from "../utils/index";

ReactModal.setAppElement("#root");
function Modal({ modalStatus, handleClose, launch }) {
	return (
		<ReactModal
			style={{
				overlay: {
					position: "fixed",
					top: 0,
					left: 0,
					right: 0,
					bottom: 0,
					backgroundColor: "rgba(192,192,192,0.6)",
					zIndex: 1000,
				},
				content: {
					position: "absolute",
					left: "40%",
					transform: "translateX(-50%)",
					border: "1px solid #ccc",
					background: "#fff",
					overflow: "auto",
					WebkitOverflowScrolling: "touch",
					borderRadius: "6px",
					outline: "none",
					width: "600px",
					maxHeight: "800px",
					padding: "0px !important",
					margin: "0 auto",
				},
			}}
			isOpen={modalStatus}
			onRequestClose={handleClose}
		>
			<div className="modal-container">
				<div className="modal-header">
					<span className="close" onClick={handleClose}>X</span>
				</div>
				<div className="row">
					<div className="col-1">
						<img className="feild-img"
							src={launch.links.mission_patch}
							alt={launch.mission_name}
						/>
					</div>
					<div className="col">
						<p className="felid-mission-status">
							{launch.mission_name}
							<span className="field-status">{getStatusLabel(launch.launch_success)}</span>
						</p>
						<p>
						<span className="field-rocket">{launch.rocket.rocket_name}</span>
						</p>
						<div className="social-links">
					{launch.links.article_link ? (
						<a href={launch.links.article_link}>
							<Icon name="medium m" size="small" color="black" />
						</a>
					) : null}
					{launch.links.wikipedia ? (
						<a href={launch.links.wikipedia}>
							<Icon name="wikipedia w" size="small" color="grey" />
						</a>
					) : null}

					{launch.links.video_link ? (
						<a href={launch.links.video_link}>
							<Icon name="youtube play" color="red" size="small" />
						</a>
					) : null}
				</div>
					</div>
					
				</div>
				<p className="launch-description">{launch.details}</p>
				<div className="details-row">
					<ul class="list">
					<li className="field-name">Flight Number  </li>
					<li className="field-name">mission Name  </li>
					<li className="field-name">Rocket Type</li>
					<li className="field-name">Rocket Name </li>
					<li className="field-name">Manufacturer</li>
					<li className="field-name">Nationality</li>
					<li className="field-name">Launch Date </li>
					<li className="field-name">Payload Type </li>
					<li className="field-name">Orbit</li>
					<li className="field-name">Launch Site </li>
					</ul>
					<ul class="list">
						<li  className="field-name"><span className="flight-details">{launch.flight_number}</span></li>
						<li  className="field-name"><span className="flight-details">{launch.mission_name}</span></li>
						<li  className="field-name"><span className="flight-details">{launch.rocket.rocket_type}</span></li>
						<li  className="field-name"><span className="flight-details">{launch.rocket.rocket_name}</span></li>
						<li  className="field-name"> <span className="flight-details">{
								launch.rocket.second_stage.payloads[0]
									.manufacturer
							}</span></li>
						<li  className="field-name"> <span className="flight-details">{launch.rocket.second_stage.payloads[0].nationality}</span></li>
						<li  className="field-name"><span className="flight-details">{getFormattedDate(launch.launch_date_utc)}</span></li>
						<li  className="field-name"><span className="flight-details">{
								launch.rocket.second_stage.payloads[0]
									.payload_type
							}</span></li>
						<li  className="field-name"> <span className="flight-details">{
								launch.rocket.second_stage.payloads[0]
									.orbit
							}</span></li>
						<li  className="field-name"><span className="flight-details">{launch.launch_site.site_name}</span></li>
					</ul>
				</div>
				
			</div>
		</ReactModal>
	);
}

export default Modal;
