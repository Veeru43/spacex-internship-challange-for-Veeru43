import React, { useState, useEffect } from "react";
import axios from "axios";
import { withRouter } from "react-router";
import FilterByStatus from "./FilterByStatus";
import LaunchList from "./LaunchList";
import { generateSearchTerm, getParamsFromUrl } from "../utils/index";

function Dashboard({ props }) {
	let urlStatus;
	getParamsFromUrl(props.location.search);
	const [launches, setlaunches] = useState([]);
	const [status, setStatus] = useState(urlStatus);
	const [activePage, setActivePage] = useState(1);
	const [launchCount, setLaunchCount] = useState("");
	const [isLoading, setIsLoading] = useState(Boolean);

	const getLaunches = async (searchTerm) => {
		try {
			setIsLoading(true);
			const res = await axios.get(
				`https://api.spacexdata.com/v3/launches${searchTerm}`
			);
			setLaunchCount(res.headers["spacex-api-count"]);
			setlaunches(res.data);
			setIsLoading(false);
		} catch (error) {
			console.log(error);
		}
	};

	useEffect(() => {
		const term = generateSearchTerm(
			status,
			activePage
		);
		getLaunches(term);
		props.history.push(term);
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [status, activePage]);

	return (
		<>
			<div className="dashboard-container">
				<div className="filters-container">
					<div className="multiple-filters">
						<FilterByStatus status={status} setStatus={setStatus} />
					</div>
				</div>

				<LaunchList
					isLoading={isLoading}
					launches={launches}
					activePage={activePage}
					setActivePage={setActivePage}
					launchCount={launchCount}
				/>
			</div>
		</>
	);
}

export default withRouter(Dashboard);
