import React from "react";

function Navbar() {
	return (
		<div className="header-container center-div">
			<div className="logo-container">
				<h1>SpaceX Dashboard</h1>
			</div>
		</div>
	);
}

export default Navbar;
